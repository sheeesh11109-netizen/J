<?php get_header(); 

// Check if we're showing popular posts
$show_popular = isset($_GET['show']) && $_GET['show'] === 'popular';
?>

<main class="blog-page">
    <!-- Hero Section -->
    <section class="blog-hero">
        <div class="container">
            <h1 class="page-title"><?php echo $show_popular ? 'Popular Articles' : 'Our Blog'; ?></h1>
            <p class="page-description">Stay updated with the latest automotive insights, reviews, and maintenance tips.</p>
        </div>
    </section>

    <div class="container">
        <section class="blog-section">
            <div class="section-header">
                <h2><?php echo $show_popular ? 'Most Read Articles' : 'Featured Articles'; ?></h2>
                <div class="section-line"></div>
            </div>
            
            <div class="articles-grid">
                <?php
                $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
                $args = array(
                    'post_type' => 'post',
                    'posts_per_page' => 9,
                    'paged' => $paged
                );

                if ($show_popular) {
                    $args['meta_key'] = 'post_views_count';
                    $args['orderby'] = 'meta_value_num';
                    $args['order'] = 'DESC';
                } else {
                    $args['meta_key'] = '_is_featured';
                    $args['meta_value'] = 'yes';
                }

                $query = new WP_Query($args);
                
                if ($query->have_posts()) :
                    while ($query->have_posts()) : $query->the_post();
                    ?>
                    <article class="blog-card">
                        <a href="<?php the_permalink(); ?>" class="card-image">
                            <?php if (has_post_thumbnail()) : ?>
                                <?php the_post_thumbnail('medium_large'); ?>
                            <?php else : ?>
                                <div class="placeholder-image">
                                    <i class="fas fa-car"></i>
                                    <span class="placeholder-text">No Image Available</span>
                                </div>
                            <?php endif; ?>
                        </a>
                        <div class="card-content">
                            <div class="card-meta">
                                <span class="meta-item"><i class="far fa-calendar"></i><?php echo get_the_date(); ?></span>
                                <span class="meta-item"><?php the_category(', '); ?></span>
                                <span class="meta-item"><i class="far fa-eye"></i><?php echo engine_dynamo_get_post_views(); ?> views</span>
                            </div>
                            <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                            <p><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p>
                            <a href="<?php the_permalink(); ?>" class="read-more">Read More <i class="fas fa-arrow-right"></i></a>
                        </div>
                    </article>
                    <?php
                    endwhile;
                    wp_reset_postdata();
                else :
                    echo '<p>No posts found.</p>';
                endif;
                ?>
            </div>

            <div class="pagination">
                <?php
                echo paginate_links(array(
                    'current' => $paged,
                    'total' => $query->max_num_pages,
                    'prev_text' => '&laquo; Previous',
                    'next_text' => 'Next &raquo;'
                ));
                ?>
            </div>
        </section>
    </div>
</main>

<style>
.blog-page {
    background: radial-gradient(circle at top left, #0d1117, #000814 80%);
    color: #e5e5e5;
    min-height: 100vh;
    padding-bottom: 80px;
}

.blog-hero {
    text-align: center;
    padding: 100px 0;
    background: linear-gradient(180deg, rgba(13,17,23,0.9) 0%, rgba(0,8,20,0.95) 100%);
    margin-bottom: 60px;
}

.blog-hero .page-title {
    font-size: 3.5rem;
    font-weight: 800;
    margin-bottom: 20px;
    background: linear-gradient(135deg, #0ea5a4 0%, #06b6d4 40%, #3b82f6 80%);
    -webkit-background-clip: text;
    background-clip: text;
    -webkit-text-fill-color: transparent;
}

.blog-hero .page-description {
    font-size: 1.2rem;
    color: #94a3b8;
    max-width: 600px;
    margin: 0 auto;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}

.section-header {
    text-align: center;
    margin-bottom: 40px;
}

.section-header h2 {
    font-size: 2.5rem;
    font-weight: 700;
    color: #fff;
    margin-bottom: 15px;
}

.section-line {
    width: 80px;
    height: 4px;
    background: #0066ff;
    margin: 0 auto;
    border-radius: 2px;
}

.articles-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
    gap: 30px;
    margin-bottom: 40px;
}

.blog-card {
    background: rgba(18, 22, 30, 0.95);
    border: 1px solid rgba(255, 255, 255, 0.05);
    border-radius: 16px;
    overflow: hidden;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    height: 100%;
    display: flex;
    flex-direction: column;
}

.blog-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 20px 40px rgba(0, 170, 255, 0.15);
    border-color: rgba(0, 170, 255, 0.3);
}

.card-image {
    position: relative;
    padding-top: 60%;
    overflow: hidden;
    display: block;
}

.card-image img {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.5s ease;
}

.blog-card:hover .card-image img {
    transform: scale(1.1);
}

.card-content {
    padding: 25px;
    flex-grow: 1;
    display: flex;
    flex-direction: column;
}

.card-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
    font-size: 0.85rem;
    color: #94a3b8;
    margin-bottom: 15px;
}

.meta-item {
    display: flex;
    align-items: center;
    gap: 5px;
}

.meta-item i {
    color: #0066ff;
}

.card-content h3 {
    font-size: 1.3rem;
    font-weight: 700;
    margin-bottom: 12px;
    line-height: 1.4;
}

.card-content h3 a {
    color: #fff;
    text-decoration: none;
    transition: color 0.3s ease;
}

.card-content h3 a:hover {
    color: #0066ff;
}

.card-content p {
    color: #94a3b8;
    line-height: 1.6;
    margin-bottom: 20px;
    flex-grow: 1;
}

.read-more {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 25px;
    background: linear-gradient(135deg, #0066ff 0%, #0099ff 100%);
    color: #fff;
    text-decoration: none;
    border-radius: 8px;
    font-weight: 600;
    transition: all 0.3s ease;
    width: fit-content;
    margin-top: auto;
}

.read-more:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0, 102, 255, 0.4);
}

.pagination {
    text-align: center;
    margin-top: 60px;
}

.pagination .page-numbers {
    display: inline-block;
    padding: 10px 20px;
    margin: 0 5px;
    border-radius: 8px;
    background: rgba(255, 255, 255, 0.05);
    color: #fff;
    text-decoration: none;
    transition: all 0.3s ease;
}

.pagination .page-numbers.current {
    background: #0066ff;
}

.pagination .page-numbers:hover:not(.current) {
    background: rgba(0, 102, 255, 0.3);
}

.placeholder-image {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.3);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: #94a3b8;
}

.placeholder-icon {
    font-size: 2rem;
    margin-bottom: 10px;
}

.placeholder-text {
    font-size: 0.9rem;
}

@media (max-width: 768px) {
    .articles-grid {
        grid-template-columns: 1fr;
    }
    
    .blog-hero .page-title {
        font-size: 2.5rem;
    }
}
</style>

<?php get_footer(); ?>