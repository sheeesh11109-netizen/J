<?php
/**
 * The template for displaying the Disclaimer page
 *
 * @package EngineDynamo
 */

get_header(); ?>

<main id="primary" class="site-main">
    <div class="container">
        
        <!-- Disclaimer Header -->
        <header class="page-header">
            <h1 class="page-title">Disclaimer</h1>
            <p class="page-description">Important information about the content and services provided on our website</p>
        </header>

        <!-- Breadcrumb Navigation -->
        <nav class="breadcrumb">
            <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
            <span class="breadcrumb-separator">›</span>
            <span class="breadcrumb-current">Disclaimer</span>
        </nav>

        <div class="legal-content">
            
            <!-- General Disclaimer -->
            <section class="legal-section">
                <h2>1. General Disclaimer</h2>
                <p>The information on this website is provided on an "as is" basis. To the fullest extent permitted by law, Engine Dynamo excludes all representations, warranties, conditions and terms relating to our website and the use of this website.</p>
                <p>Nothing in this disclaimer will:</p>
                <ul>
                    <li>Limit or exclude our or your liability for death or personal injury</li>
                    <li>Limit or exclude our or your liability for fraud or fraudulent misrepresentation</li>
                    <li>Limit any of our or your liabilities in any way that is not permitted under applicable law</li>
                    <li>Exclude any of our or your liabilities that may not be excluded under applicable law</li>
                </ul>
            </section>

            <!-- Content Accuracy -->
            <section class="legal-section">
                <h2>2. Content Accuracy and Reliability</h2>
                <p>While we strive to provide accurate and up-to-date information, we make no representations or warranties of any kind, express or implied, about the completeness, accuracy, reliability, suitability, or availability of the information, products, services, or related graphics contained on this website.</p>
                <p>Any reliance you place on such information is therefore strictly at your own risk. We recommend consulting with qualified automotive professionals before making any decisions based on the information provided on our website.</p>
            </section>

            <!-- Professional Advice -->
            <section class="legal-section">
                <h2>3. Professional Advice Disclaimer</h2>
                <p>The content on Engine Dynamo is for informational and educational purposes only. It is not intended to be a substitute for professional automotive advice, diagnosis, or treatment.</p>
                <p>Always seek the advice of qualified automotive professionals with any questions you may have regarding vehicle maintenance, repairs, or modifications. Never disregard professional advice or delay in seeking it because of something you have read on our website.</p>
            </section>

            <!-- Safety Information -->
            <section class="legal-section">
                <h2>4. Safety and Liability</h2>
                <p>Automotive work can be dangerous and should only be performed by qualified individuals. We strongly advise against attempting any automotive repairs or modifications without proper knowledge, tools, and safety equipment.</p>
                <p>Engine Dynamo and its contributors are not responsible for any injuries, damages, or losses that may result from following the information provided on this website. Always prioritize safety and consult with professionals when in doubt.</p>
            </section>

            <!-- External Links -->
            <section class="legal-section">
                <h2>5. External Links and Third-Party Content</h2>
                <p>Our website may contain links to external websites that are not provided or maintained by Engine Dynamo. We do not guarantee the accuracy, relevance, timeliness, or completeness of any information on these external websites.</p>
                <p>The inclusion of any links does not necessarily imply a recommendation or endorse the views expressed within them. We have no control over the nature, content, and availability of those sites.</p>
            </section>

            <!-- Product Recommendations -->
            <section class="legal-section">
                <h2>6. Product Recommendations and Reviews</h2>
                <p>Any product recommendations, reviews, or endorsements on our website are based on our research and experience. However, individual results may vary, and we cannot guarantee the performance, quality, or suitability of any products or services mentioned.</p>
                <p>We encourage you to conduct your own research and consult with professionals before making any purchasing decisions. We are not responsible for any issues that may arise from the use of recommended products or services.</p>
            </section>

            <!-- Technical Information -->
            <section class="legal-section">
                <h2>7. Technical Information and Specifications</h2>
                <p>Technical information, specifications, and procedures provided on our website are for general guidance only. Vehicle specifications and procedures may vary by make, model, year, and other factors.</p>
                <p>Always refer to your vehicle's owner's manual and consult with qualified technicians for specific information about your vehicle. We are not responsible for any damage that may result from following general procedures that may not apply to your specific vehicle.</p>
            </section>

            <!-- Limitation of Liability -->
            <section class="legal-section">
                <h2>8. Limitation of Liability</h2>
                <p>In no event shall Engine Dynamo, its officers, directors, employees, or agents be liable for any direct, indirect, incidental, special, consequential, or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your use of our website.</p>
                <p>This limitation of liability applies to the fullest extent permitted by law and shall survive any termination of your use of our website.</p>
            </section>

            <!-- Indemnification -->
            <section class="legal-section">
                <h2>9. Indemnification</h2>
                <p>You agree to defend, indemnify, and hold harmless Engine Dynamo and its affiliates from and against any and all claims, damages, obligations, losses, liabilities, costs, or debt, and expenses (including attorney's fees) arising from your use of our website or violation of these terms.</p>
            </section>

            <!-- Governing Law -->
            <section class="legal-section">
                <h2>10. Governing Law and Jurisdiction</h2>
                <p>This disclaimer shall be governed by and construed in accordance with the laws of Bangladesh, without regard to its conflict of law provisions. Any disputes arising from this disclaimer shall be subject to the exclusive jurisdiction of the courts in Bangladesh.</p>
            </section>

            <!-- Changes to Disclaimer -->
            <section class="legal-section">
                <h2>11. Changes to This Disclaimer</h2>
                <p>We reserve the right to modify this disclaimer at any time. Changes will be effective immediately upon posting on our website. Your continued use of our website after any changes constitutes acceptance of the new disclaimer.</p>
                <p>We encourage you to review this disclaimer periodically to stay informed of any updates.</p>
            </section>

            <!-- Contact details removed -->

            <!-- Last Updated -->
            <section class="legal-section">
                <p class="last-updated"><strong>Last updated:</strong> <?php echo date('F j, Y'); ?></p>
            </section>
            
        </div>
        
    </div>
</main>

<?php
get_footer();
