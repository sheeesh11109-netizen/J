(function(window, document, $){
    'use strict';

    // Only run when on a single post (engineDynamoViews.is_single === 1)
    if (typeof engineDynamoViews === 'undefined' || !engineDynamoViews.is_single || !engineDynamoViews.post_id) {
        return;
    }

    var postId = engineDynamoViews.post_id;
    var storageKey = 'ed_viewed_' + postId;

    // Use localStorage for dedupe (falls back to cookie if localStorage unavailable)
    function hasSeen() {
        try {
            if (window.localStorage) {
                return !!localStorage.getItem(storageKey);
            }
        } catch (e) {}

        // fallback to cookie
        var m = document.cookie.match(new RegExp('(^| )' + storageKey + '=1($|;)'));
        return !!m;
    }

    function markSeen() {
        try {
            if (window.localStorage) {
                localStorage.setItem(storageKey, Date.now());
                return;
            }
        } catch (e) {}
        // fallback cookie for 30 days
        var d = new Date();
        d.setTime(d.getTime() + (30*24*60*60*1000));
        document.cookie = storageKey + '=1; expires=' + d.toUTCString() + '; path=/';
    }

    if (hasSeen()) return;

    // Fire AJAX to record view
    $.post(engineDynamoViews.ajax_url, {
        action: 'engine_dynamo_record_view',
        post_id: postId,
        nonce: engineDynamoViews.nonce
    }).done(function(resp){
        if (resp && resp.success) {
            markSeen();
        }
    }).fail(function(){
        // best-effort: still mark seen to avoid spamming endpoint on repeated loads
        markSeen();
    });

})(window, document, jQuery);