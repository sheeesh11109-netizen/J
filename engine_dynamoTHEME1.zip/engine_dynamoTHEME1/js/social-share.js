document.addEventListener('DOMContentLoaded', function() {
    // Social sharing functionality - target the template's `.share-btn` elements
    const shareButtons = document.querySelectorAll('.share-btn');

    shareButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            // If the element is a <button> used for copy-link, handle separately
            if (this.classList.contains('copy-link')) {
                e.preventDefault();
                const url = this.dataset.url || window.location.href;
                if (navigator.clipboard) {
                    navigator.clipboard.writeText(url).then(() => {
                        const original = this.innerHTML;
                        this.innerHTML = '<i class="fas fa-check"></i> Copied!';
                        setTimeout(() => this.innerHTML = original, 2000);
                    }).catch(() => alert('Unable to copy link.'));
                } else {
                    // Fallback for older browsers
                    const tmp = document.createElement('input');
                    document.body.appendChild(tmp);
                    tmp.value = url;
                    tmp.select();
                    try { document.execCommand('copy'); alert('Link copied to clipboard.'); } catch (err) { alert('Copy failed.'); }
                    tmp.remove();
                }
                return;
            }

            e.preventDefault();

            // Determine platform either from data-platform or from class names
            let platform = this.dataset.platform || '';
            if (!platform) {
                if (this.classList.contains('facebook')) platform = 'facebook';
                else if (this.classList.contains('whatsapp')) platform = 'whatsapp';
                else if (this.classList.contains('linkedin')) platform = 'linkedin';
                else if (this.classList.contains('pinterest')) platform = 'pinterest';
                else if (this.classList.contains('email')) platform = 'email';
            }

            const url = encodeURIComponent(this.dataset.url || window.location.href);
            const title = encodeURIComponent(document.title);

            let shareUrl;

            switch(platform) {
                case 'facebook':
                    shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${url}`;
                    break;
                case 'whatsapp':
                    shareUrl = `https://api.whatsapp.com/send?text=${title}%20${url}`;
                    break;
                case 'linkedin':
                    shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${url}`;
                    break;
                case 'pinterest':
                    const image = encodeURIComponent(document.querySelector('meta[property="og:image"]')?.content || '');
                    shareUrl = `https://pinterest.com/pin/create/button/?url=${url}&media=${image}&description=${title}`;
                    break;
                case 'email':
                    shareUrl = `mailto:?subject=${title}&body=Check this out: ${url}`;
                    break;
            }

            if (shareUrl) {
                window.open(shareUrl, '_blank', 'width=600,height=500,toolbar=0,menubar=0,location=0');
            }
        });
    });
});