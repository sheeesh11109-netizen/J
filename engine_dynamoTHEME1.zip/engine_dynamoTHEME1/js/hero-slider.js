(function($){
    $(function(){
        // Ensure Swiper is available
        if (typeof Swiper === 'undefined') return;

        var el = document.querySelector('.heroSwiper');
        if (!el) return;

        // Initialize cinematic hero Swiper
        new Swiper('.heroSwiper', {
            slidesPerView: 1,
            loop: true,
            effect: 'fade',
            fadeEffect: { crossFade: true },
            speed: 1500,
            autoplay: { delay: 5000, disableOnInteraction: false },
            pagination: { el: '.swiper-pagination', clickable: true },
            a11y: { enabled: true },
            keyboard: { enabled: true, onlyInViewport: true },
            grabCursor: true,
            preloadImages: false,
            lazy: { loadOnTransitionStart: true, loadPrevNext: true },
        });
    });
})(jQuery);