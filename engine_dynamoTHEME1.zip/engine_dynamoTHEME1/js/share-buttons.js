// Handle copy link button
document.addEventListener('DOMContentLoaded', function() {
    const copyButtons = document.querySelectorAll('.copy-link');
    copyButtons.forEach(button => {
        button.addEventListener('click', function() {
            const url = this.getAttribute('data-url');
            navigator.clipboard.writeText(url).then(() => {
                const icon = this.querySelector('i');
                const span = this.querySelector('span');
                const originalIcon = icon.className;
                const originalText = span.textContent;
                
                // Change to checkmark and "Copied!"
                icon.className = 'fas fa-check';
                span.textContent = 'Copied!';
                
                // Revert back after 2 seconds
                setTimeout(() => {
                    icon.className = originalIcon;
                    span.textContent = originalText;
                }, 2000);
            }).catch(err => {
                console.error('Failed to copy: ', err);
            });
        });
    });

    // Add click handlers for sharing buttons
    const shareButtons = document.querySelectorAll('.share-btn');
    shareButtons.forEach(button => {
        if (!button.classList.contains('copy-link')) {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                window.open(this.href, 'share-window', 'height=450, width=550, top=' + 
                    (window.innerHeight / 2 - 225) + ', left=' + 
                    (window.innerWidth / 2 - 275) + ', toolbar=0, location=0, menubar=0, directories=0, scrollbars=0');
            });
        }
    });
});