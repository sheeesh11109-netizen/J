/**
 * Enhanced Navigation with Touch Device Detection
 * Optimized for mobile, tablet, and desktop
 */

(function($) {
    'use strict';

    // Enhanced device detection function
    function isMobileOrTablet() {
        // Check for touch support
        const isTouchDevice = ('ontouchstart' in window) || 
                              (navigator.maxTouchPoints > 0) || 
                              (navigator.msMaxTouchPoints > 0);
        
        // Check user agent for mobile/tablet devices
        const userAgent = navigator.userAgent.toLowerCase();
        const mobileKeywords = /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini|mobile|tablet/i;
        const isMobileUA = mobileKeywords.test(userAgent);
        
        // Check media queries for screen width (1024px breakpoint to include tablets)
        const isSmallScreen = window.matchMedia('(max-width: 1024px)').matches;
        
        // Check for touch-only devices using hover capability
        const isTouchOnly = window.matchMedia('(hover: none) and (pointer: coarse)').matches;
        
        // Device is mobile/tablet if ANY of these conditions are true
        return isTouchDevice || isMobileUA || isSmallScreen || isTouchOnly;
    }

    // Navigation initialization
    function initNavigation() {
        // Mobile menu toggle
        $('.menu-toggle').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).toggleClass('active');
            $('.main-navigation').toggleClass('active');
            $('body').toggleClass('menu-open');
        });

        // Determine and setup navigation mode based on device type
        function setupNavigationMode() {
            const isMobile = isMobileOrTablet();
            
            if (isMobile) {
                // Mobile/Tablet mode - click to toggle dropdowns
                $('.nav-item.dropdown').off('mouseenter mouseleave');
                
                $('.nav-item.dropdown .nav-link').off('click').on('click', function(e) {
                    const $link = $(this);
                    const href = $link.attr('href');
                    const $parent = $link.parent();
                    const $dropdown = $link.siblings('.dropdown-menu');

                    // If there is no dropdown menu, allow normal navigation
                    if (!$dropdown.length) {
                        return;
                    }

                    // On mobile, if there's a dropdown, the first tap should ALWAYS open the submenu
                    // This ensures submenus are accessible even when parent has a real href
                    
                    // Check if dropdown is already open
                    if ($parent.hasClass('active')) {
                        // Dropdown is open - now allow navigation if href exists
                        if (href && href !== '#') {
                            return; // Allow navigation on second tap
                        }
                    }
                    
                    // First tap or parent has no href - toggle dropdown
                    e.preventDefault();

                    // Close any other open dropdowns
                    $('.nav-item.dropdown').not($parent).removeClass('active')
                        .find('.dropdown-menu').slideUp(300);

                    // Toggle current dropdown
                    $parent.toggleClass('active');
                    $dropdown.stop(true, true).slideToggle(300);
                });
            } else {
                // Desktop mode - hover for dropdowns
                $('.nav-item.dropdown .nav-link').off('click');
                
                $('.nav-item.dropdown').off('mouseenter mouseleave').hover(
                    function() {
                        $(this).addClass('open');
                    },
                    function() {
                        $(this).removeClass('open');
                    }
                );
            }
            
            // Log device type for debugging (remove in production)
            if (window.console && window.console.log) {
                console.log('Navigation Mode:', isMobile ? 'Mobile/Tablet' : 'Desktop', {
                    isTouchDevice: ('ontouchstart' in window),
                    screenWidth: window.innerWidth,
                    userAgent: navigator.userAgent.substring(0, 50) + '...'
                });
            }
        }

        // Initialize navigation mode on load
        setupNavigationMode();

        // Close mobile menu when clicking outside
        $(document).on('click', function(e) {
            if (!$(e.target).closest('.main-navigation, .menu-toggle').length) {
                $('.main-navigation').removeClass('active');
                $('.menu-toggle').removeClass('active');
                $('body').removeClass('menu-open');
                $('.nav-item.dropdown').removeClass('active');
                $('.dropdown-menu').slideUp(300);
            }
        });

        // Handle window resize - reconfigure navigation mode
        let resizeTimer;
        $(window).on('resize', function() {
            // IMMEDIATELY hide mobile menu to prevent visual glitch during resize
            $('.main-navigation').removeClass('active');
            $('.menu-toggle').removeClass('active');
            $('body').removeClass('menu-open');
            $('.dropdown-menu').removeAttr('style').removeClass('open');
            $('.nav-item.dropdown').removeClass('open active');
            
            // Debounce the reconfiguration
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(function() {
                // Reconfigure navigation based on current device type
                setupNavigationMode();
            }, 250);
        });

        // Handle orientation change for mobile devices
        $(window).on('orientationchange', function() {
            setTimeout(function() {
                setupNavigationMode();
            }, 300);
        });
    }

    // Export for WordPress integration
    window.engineDynamoNav = {
        init: initNavigation,
        isMobileOrTablet: isMobileOrTablet
    };

    // Auto-initialize when DOM is ready
    $(document).ready(function() {
        initNavigation();
    });

})(jQuery);
