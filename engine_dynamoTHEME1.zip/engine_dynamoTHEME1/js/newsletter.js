/**
 * Newsletter front-end controller
 * Handles popup triggers, form submission and feedback
 */
(function () {
	'use strict';

	// Helpers
	function setCookie(name, value, days) {
		const d = new Date();
		d.setTime(d.getTime() + (days * 24 * 60 * 60 * 1000));
		document.cookie = `${name}=${value};expires=${d.toUTCString()};path=/;SameSite=Lax`;
	}

	function getCookie(name) {
		const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
		return match ? match[2] : null;
	}

	// Show/Hide popup
	function showPopup(popup) {
		if (!popup) return;
		popup.style.display = 'flex';
		requestAnimationFrame(() => popup.classList.add('show'));
		sessionStorage.setItem('ed_popup_shown', '1');
	}

	function hidePopup(popup) {
		if (!popup) return;
		popup.classList.remove('show');
		setTimeout(() => { popup.style.display = 'none'; }, 350);
	}

	// Form handler
	async function submitNewsletterForm(form) {
		if (!form) return;
		const submitBtn = form.querySelector('button[type="submit"]') || form.querySelector('input[type="submit"]');
		const feedback = form.querySelector('.newsletter-feedback') || form.querySelector('.newsletter-response');

		// Basic HTML5 validation
		if (!form.checkValidity()) {
			form.reportValidity();
			return;
		}

		const data = new FormData(form);
		data.append('action', 'engine_dynamo_newsletter');
		if (typeof engineDynamoAjax !== 'undefined' && engineDynamoAjax.nonce) {
			data.append('nonce', engineDynamoAjax.nonce);
		}

		// UI: loading
		if (submitBtn) { submitBtn.disabled = true; submitBtn.classList.add('loading'); }

		try {
			const res = await fetch((engineDynamoAjax && engineDynamoAjax.ajaxUrl) || '/wp-admin/admin-ajax.php', {
				method: 'POST',
				body: data,
				credentials: 'same-origin'
			});

			const json = await res.json();
			if (json && json.success) {
				if (feedback) {
					feedback.innerHTML = `<div class="newsletter-success"><span>${json.data.message}</span><button type="button" class="newsletter-dismiss">Dismiss</button></div>`;
					const btn = feedback.querySelector('.newsletter-dismiss');
					if (btn) btn.addEventListener('click', () => { feedback.innerHTML = ''; });
				}
				form.reset();
				setCookie('ed_newsletter_subscribed', 'true', 365);
				// If this form is inside popup, close it shortly
				const popup = form.closest('.newsletter-popup');
				if (popup) setTimeout(() => hidePopup(popup), 1600);
			} else {
				const msg = (json && json.data && json.data.message) ? json.data.message : 'An error occurred.';
				if (feedback) feedback.innerHTML = `<div class="newsletter-error">${msg}</div>`;
			}
		} catch (err) {
			if (feedback) feedback.innerHTML = `<div class="newsletter-error">Network error. Please try again.</div>`;
		} finally {
			if (submitBtn) { submitBtn.disabled = false; submitBtn.classList.remove('loading'); }
		}
	}

	// Init popup triggers and form bindings
	function init() {
		// Popup element included via template part (footer)
		const popup = document.getElementById('newsletter-popup');

		// If popup exists, wire up trigger rules
		if (popup) {
			// Don't show if user already subscribed or dismissed
			if (!getCookie('ed_newsletter_subscribed') && !getCookie('ed_newsletter_dismissed') && !sessionStorage.getItem('ed_popup_shown')) {
				// Do not show the popup on small/mobile screens to avoid stretched layouts
				if (window.innerWidth < 768) {
					// exit early on mobile
				} else {
					// Time trigger (120s) — increase to make popup less frequent
					const timer = setTimeout(() => showPopup(popup), 120000);

				// Scroll trigger (75%)
				const onScroll = () => {
					const scrolled = (window.scrollY + window.innerHeight) / document.documentElement.scrollHeight;
					if (scrolled > 0.75) {
						clearTimeout(timer);
						showPopup(popup);
						window.removeEventListener('scroll', onScroll);
					}
				};
					window.addEventListener('scroll', onScroll, { passive: true });
				}
			}

			// Close handlers
			const closeBtn = popup.querySelector('.close-popup');
			// When user dismisses popup, remember for 30 days instead of 7
			if (closeBtn) closeBtn.addEventListener('click', () => { hidePopup(popup); setCookie('ed_newsletter_dismissed', '1', 30); });
			popup.addEventListener('click', (e) => { if (e.target === popup) { hidePopup(popup); setCookie('ed_newsletter_dismissed', '1', 30); } });
		document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && popup.classList.contains('show')) { hidePopup(popup); setCookie('ed_newsletter_dismissed', '1', 30); } });
		}

		// Bind to all newsletter forms (popup and inline)
		document.querySelectorAll('.newsletter-form, .popup-newsletter-form').forEach(form => {
			form.addEventListener('submit', function (e) {
				e.preventDefault();
				submitNewsletterForm(form);
			});
		});

		// Resubscribe links
		document.querySelectorAll('.resubscribe-link').forEach(link => {
			link.addEventListener('click', (e) => {
				e.preventDefault();
				// clear dismiss cookie and show popup
				setCookie('ed_newsletter_dismissed', '', -1);
				const popupElem = document.getElementById('newsletter-popup');
				if (popupElem) showPopup(popupElem);
			});
		});
	}

	// DOM ready
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}

})();

