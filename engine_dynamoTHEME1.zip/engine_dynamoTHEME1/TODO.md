f# Task: Update Maintenance Tips Category Page

## Reading Time Functionality
- [x] Add reading time calculation function in functions.php (200 words per minute)
- [x] Add customizable reading time via custom field "reading_time_override"
- [x] Display reading time in post meta section

## Category Query Changes
- [x] Modify category.php to include posts from current category AND all subcategories
- [x] Update posts grid to show all relevant posts

## Layout Improvements
- [x] Improve post cards layout for better presentation
- [x] Ensure responsive design

## Navigation Menu Fixes
- [x] Fix parent category menu links to point to category archives instead of blog page
- [x] Add checks for category existence before linking
- [x] Update Maintenance Tips, Tires & Parts, and Car Reviews parent links

## Followup Steps
- [x] Test category page functionality
- [x] Verify reading time display
- [x] Check subcategory posts inclusion
- [x] Added reading time to home.php blog page as well
- [x] Fixed navigation menu links for parent categories
- [x] Removed duplicate newsletter sections from category pages

## Blog Page Excerpt Fix
- [x] Replace the_excerpt() with wp_trim_words() in page-blog.php and category.php to limit content display
- [x] Updated functions.php live search to use get_the_content() instead of get_the_excerpt()

## Footer Restructure
- [x] Update footer.php to have two columns: first with About Us, Contact, Disclaimer; second with social links, copyright, tagline
- [x] Add Instagram and Facebook social links
- [x] Remove Terms & Conditions and Privacy Policy links

## Newsletter UI Fix
- [x] Check and fix newsletter form styling in single.php and other locations

## Progress
- [x] Analyzed files and planned changes
- [x] Added reading time function
- [x] Updated category.php query
- [x] Updated post display
- [x] Fixed navigation menu links
- [x] Updated prevent redirect function for subcategories
- [x] Fix blog page excerpt display
- [x] Restructure footer
- [x] Fix newsletter UI
