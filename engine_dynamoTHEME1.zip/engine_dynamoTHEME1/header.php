<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <!-- Favicon (theme logo). We try an inline SVG data-uri first (works in modern Chrome/Edge/Firefox),
         then fall back to a theme-root favicon.ico for older browsers. -->
    <?php
    // Prefer a PNG favicon placed at /assets/images/favicon.png inside the child or parent theme.
    // This meets the requirement to use favicon.png and not change any UI or logo.svg used in the navbar.
    $child_png = get_stylesheet_directory() . '/assets/images/favicon.png';
    $parent_png = get_template_directory() . '/assets/images/favicon.png';
    $favicon_uri = '';
    if ( file_exists( $child_png ) ) {
        $favicon_uri = get_stylesheet_directory_uri() . '/assets/images/favicon.png';
    } elseif ( file_exists( $parent_png ) ) {
        $favicon_uri = get_template_directory_uri() . '/assets/images/favicon.png';
    }
    if ( $favicon_uri ) {
        // Standard icon link and legacy shortcut icon for broad compatibility
        echo '<link rel="icon" href="' . esc_url( $favicon_uri ) . '" type="image/png" sizes="32x32">';
        echo '<link rel="shortcut icon" href="' . esc_url( $favicon_uri ) . '" type="image/png">';
    }

    // Existing SVG-logo-based favicon behavior (left intact so your header logo remains unchanged)
    $svg_path = get_template_directory() . '/assets/images/logo.svg';
    if ( file_exists( $svg_path ) ) {
        $svg = file_get_contents( $svg_path );
        // Normalize quotes and whitespace to be safe inside the data URI
        $svg = trim( preg_replace('/\s+/', ' ', $svg) );
        $svg = str_replace('"', "'", $svg);
        $svg_data = 'data:image/svg+xml;utf8,' . rawurlencode( $svg );
        // Inline data-uri (fast) and explicit file link (some browsers prefer the file)
        echo '<link rel="icon" href="' . esc_url( $svg_data ) . '" type="image/svg+xml">';
        echo '<link rel="icon" href="' . esc_url( get_template_directory_uri() . '/assets/images/logo.svg' ) . '" type="image/svg+xml">';
    }

    // Always include a classic favicon.ico fallback in the theme root
    echo '<link rel="icon" href="' . esc_url( get_template_directory_uri() . '/favicon.ico' ) . '" type="image/x-icon">';
    ?>
    <meta name="theme-color" content="#0A0F1C">
    
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">
    <a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e('Skip to content', 'engine-dynamo'); ?></a>

    <header id="masthead" class="site-header">
        <div class="container">
            <div class="header-content">
                <!-- Left: Logo -->
                <div class="site-branding header-left">
                    <a href="<?php echo esc_url(home_url('/')); ?>" class="site-logo" rel="home">
                        <?php if (has_custom_logo()) : ?>
                            <?php 
                            // Get the custom logo HTML
                            $custom_logo_id = get_theme_mod('custom_logo');
                            $custom_logo_img = wp_get_attachment_image($custom_logo_id, 'full', false, array('class' => 'custom-logo'));
                            // Output the custom logo
                            echo $custom_logo_img;
                            ?>
                        <?php else : ?>
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo.svg" alt="Engine Dynamo" />
                        <?php endif; ?>
                        <div class="logo-text">
                            <span class="engine">ENGINE</span>
                            <span class="dynamo">DYNAMO</span>
                        </div>
                    </a>
                </div>

                <!-- Center: Navigation -->
                <nav id="site-navigation" class="main-navigation header-center" aria-label="Primary Navigation">
                    <button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">
                        <span class="hamburger"></span>
                        <span class="hamburger"></span>
                        <span class="hamburger"></span>
                    </button>
                    <?php
                    wp_nav_menu(array(
                        'theme_location' => 'primary',
                        'menu_id'        => 'primary-menu',
                        'menu_class'     => 'nav-menu centered-nav',
                        'container'      => false,
                        'fallback_cb'    => 'engine_dynamo_fallback_menu',
                        'walker'         => new Engine_Dynamo_Nav_Walker(),
                    ));
                    ?>
                </nav>

                <!-- Right: Search + Social -->
                <div class="header-controls header-right">
                    <div class="search-container">
                        <?php get_search_form(); ?>
                    </div>
                    <div class="header-social">
                        <a href="https://www.facebook.com/profile.php?id=61580498813187" class="social-icon facebook" target="_blank" rel="noopener">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="https://www.instagram.com/engine_dynamo/" class="social-icon instagram" target="_blank" rel="noopener">
                            <i class="fab fa-instagram"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>
