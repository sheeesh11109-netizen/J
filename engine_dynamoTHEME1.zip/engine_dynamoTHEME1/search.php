<?php
/**
 * Search results template
 *
 * @package EngineDynamo
 */

get_header(); ?>

<main id="primary" class="site-main">
    <div class="container">
        <header class="page-header">
            <?php $search_query = trim( get_search_query() ); ?>
            <?php if ( $search_query === '' ) : ?>
                <h1 class="page-title"><?php esc_html_e('Search', 'engine-dynamo'); ?></h1>
                <div class="no-search-query">
                    <p><?php esc_html_e('Please enter a search term to find articles. Try a keyword like "oil change" or "brakes".', 'engine-dynamo'); ?></p>
                    <?php get_search_form(); ?>
                </div>
            <?php else : ?>
                <h1 class="page-title"><?php printf( esc_html__('Search Results for "%s"', 'engine-dynamo'), esc_html( $search_query ) ); ?></h1>
            <?php endif; ?>
        </header>

        <div class="posts-grid">
            <?php if ( $search_query !== '' && have_posts() ) : while (have_posts()) : the_post(); ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class('post-card'); ?>>
                    <div class="post-thumbnail">
                        <a href="<?php the_permalink(); ?>">
                            <?php if (has_post_thumbnail()) { the_post_thumbnail('article-thumbnail'); } else { ?>
                                <div class="placeholder-image">
                                    <span class="placeholder-icon">🚗</span>
                                    <span class="placeholder-text">Automotive</span>
                                </div>
                            <?php } ?>
                        </a>
                    </div>
                    <div class="post-content">
                        <div class="post-meta">
                            <span class="post-date"><?php echo get_the_date(); ?></span>
                            <span class="post-category"><?php the_category(', '); ?></span>
                        </div>
                        <h2 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                        <div class="post-excerpt"><?php the_excerpt(); ?></div>
                        <a href="<?php the_permalink(); ?>" class="read-more-btn">Read More</a>
                    </div>
                </article>
            <?php endwhile; elseif ( $search_query !== '' ): ?>
                <div class="no-posts">
                    <h2><?php esc_html_e('No results found', 'engine-dynamo'); ?></h2>
                    <p><?php esc_html_e('Try different keywords or browse our latest posts.', 'engine-dynamo'); ?></p>
                </div>
            <?php endif; ?>
        </div>

        <?php
        the_posts_pagination(array(
            'prev_text' => esc_html__('Previous', 'engine-dynamo'),
            'next_text' => esc_html__('Next', 'engine-dynamo'),
            'mid_size' => 2,
        ));
        ?>
    </div>
</main>

<?php get_footer();

