<?php
/**
 * The template for displaying comments
 *
 * @package EngineDynamo
 */

if (post_password_required()) {
    return;
}
?>

<div id="comments" class="comments-area">
    
    <?php if (have_comments()) : ?>
        <h2 class="comments-title">
            <?php
            $comments_number = get_comments_number();
            if ('1' === $comments_number) {
                printf(
                    esc_html__('One thought on &ldquo;%1$s&rdquo;', 'engine-dynamo'),
                    '<span>' . get_the_title() . '</span>'
                );
            } else {
                printf(
                    esc_html(_n(
                        '%1$s thought on &ldquo;%2$s&rdquo;',
                        '%1$s thoughts on &ldquo;%2$s&rdquo;',
                        $comments_number,
                        'engine-dynamo'
                    )),
                    number_format_i18n($comments_number),
                    '<span>' . get_the_title() . '</span>'
                );
            }
            ?>
        </h2>

        <ol class="comment-list">
            <?php
            wp_list_comments(array(
                'style'       => 'ol',
                'short_ping'  => true,
                'avatar_size' => 50,
                'callback'    => 'engine_dynamo_comment_callback',
                'reply_text'  => 'Reply',
                'max_depth'   => 5,
            ));
            ?>
        </ol>

        <?php
        the_comments_navigation(array(
            'prev_text' => esc_html__('Older Comments', 'engine-dynamo'),
            'next_text' => esc_html__('Newer Comments', 'engine-dynamo'),
        ));
        ?>

    <?php endif; ?>

    <?php if (!comments_open() && get_comments_number() && post_type_supports(get_post_type(), 'comments')) : ?>
        <p class="no-comments"><?php esc_html_e('Comments are closed.', 'engine-dynamo'); ?></p>
    <?php endif; ?>

    <?php
    $comment_form_args = array(
        'title_reply'          => esc_html__('Leave a Comment', 'engine-dynamo'),
        'title_reply_to'       => esc_html__('Leave a Reply to %s', 'engine-dynamo'),
        'title_reply_before'   => '<h3 id="reply-title" class="comment-reply-title">',
        'title_reply_after'    => '</h3>',
        'comment_notes_before' => '<p class="comment-notes">' . esc_html__('Your email address will not be published.', 'engine-dynamo') . '</p>',
        // Ensure the form has a stable ID so JS can move it around
        'id_form'              => 'commentform',
        'comment_field'        => '<p class="comment-form-comment"><label for="comment">' . esc_html__('Comment', 'engine-dynamo') . '</label><textarea id="comment" name="comment" cols="45" rows="8" required></textarea></p>',
        'fields'               => array(
            'author' => '<p class="comment-form-author"><label for="author">' . esc_html__('Name', 'engine-dynamo') . '</label><input id="author" name="author" type="text" value="' . esc_attr($commenter['comment_author']) . '" size="30" required /></p>',
            'email'  => '<p class="comment-form-email"><label for="email">' . esc_html__('Email', 'engine-dynamo') . '</label><input id="email" name="email" type="email" value="' . esc_attr($commenter['comment_author_email']) . '" size="30" required /></p>',
            'url'    => '<p class="comment-form-url"><label for="url">' . esc_html__('Website', 'engine-dynamo') . '</label><input id="url" name="url" type="url" value="' . esc_attr($commenter['comment_author_url']) . '" size="30" /></p>',
        ),
        'class_submit'         => 'btn btn-primary',
        'submit_button'        => '<input name="submit" type="submit" id="%2$s" class="%3$s" value="%4$s" />',
    );

    comment_form($comment_form_args);
    ?>

</div>
