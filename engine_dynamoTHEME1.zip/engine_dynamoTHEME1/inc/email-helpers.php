<?php
/**
 * Email helper functions for Engine Dynamo theme
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Get email template with common header and footer
 *
 * @param string $content The main content of the email
 * @param string $title The title to show in the email header
 * @return string The complete HTML email template
 */
function engine_dynamo_get_email_template($content, $title) {
    $template = '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
            .container { max-width: 600px; margin: 0 auto; background: #ffffff; }
            .header { background: linear-gradient(135deg, #2B6EF2 0%, #3182CE 100%); color: white; padding: 30px 20px; text-align: center; }
            .header h1 { margin: 0; font-size: 24px; }
            .content { background: #ffffff; padding: 30px 20px; }
            .footer { background: #0A0F1C; color: #8F9BB3; padding: 20px; text-align: center; font-size: 12px; }
            .button { display: inline-block; background: #2B6EF2; color: white; padding: 12px 25px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
            .info-box { background: #F7FAFC; border: 1px solid #E2E8F0; padding: 15px; margin: 15px 0; border-radius: 5px; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>' . esc_html($title) . '</h1>
            </div>
            <div class="content">
                ' . $content . '
            </div>
            <div class="footer">
                <p>ENGINE DYNAMO - Your Ultimate Automotive Resource</p>
                <p>This email was sent from ' . get_bloginfo('name') . '</p>
                <p>&copy; ' . date('Y') . ' ' . get_bloginfo('name') . '. All rights reserved.</p>
            </div>
        </div>
    </body>
    </html>';

    return $template;
}

/**
 * Send an email using WordPress mail with proper headers
 *
 * @param string $to Recipient email address
 * @param string $subject Email subject
 * @param string $message Email content (HTML)
 * @param string $from_name Optional sender name
 * @param string $from_email Optional sender email
 * @return boolean Whether the email was sent successfully
 */
function engine_dynamo_send_email($to, $subject, $message, $from_name = '', $from_email = '') {
    if (empty($from_name)) {
        $from_name = get_bloginfo('name');
    }
    if (empty($from_email)) {
        $from_email = 'noreply@' . parse_url(get_site_url(), PHP_URL_HOST);
    }

    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . $from_name . ' <' . $from_email . '>',
        'Reply-To: ' . $from_name . ' <' . $from_email . '>'
    );

    // Log email attempt
    error_log(sprintf(
        '[ENGINE DYNAMO] Sending email to %s with subject: %s',
        $to,
        $subject
    ));

    $sent = wp_mail($to, $subject, $message, $headers);

    // Log result
    if (!$sent) {
        error_log(sprintf(
            '[ENGINE DYNAMO] Failed to send email to %s. Last error: %s',
            $to,
            print_r($GLOBALS['phpmailer']->ErrorInfo, true)
        ));
    }

    return $sent;
}

/**
 * Validate and sanitize email parameters
 *
 * @param array $params Array of email parameters to validate
 * @return array|WP_Error Sanitized parameters or WP_Error on failure
 */
function engine_dynamo_validate_email_params($params) {
    $required = array('to', 'subject', 'message');
    foreach ($required as $field) {
        if (empty($params[$field])) {
            return new WP_Error('missing_required', sprintf(
                'Missing required email field: %s',
                $field
            ));
        }
    }

    return array(
        'to' => sanitize_email($params['to']),
        'subject' => sanitize_text_field($params['subject']),
        'message' => wp_kses_post($params['message']),
        'from_name' => !empty($params['from_name']) ? 
            sanitize_text_field($params['from_name']) : '',
        'from_email' => !empty($params['from_email']) ? 
            sanitize_email($params['from_email']) : ''
    );
}
