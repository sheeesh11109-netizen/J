<?php
// Enqueue Swiper.js and hero slider assets
function engine_dynamo_hero_scripts() {
    if (is_front_page()) {
        // Swiper CSS from CDN
        wp_enqueue_style('swiper-css', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css', array(), '11.0.0');
        
        // Swiper JS from CDN
        wp_enqueue_script('swiper-js', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js', array(), '11.0.0', true);
        
        // Custom hero slider JS
        wp_enqueue_script('hero-slider-js', get_template_directory_uri() . '/js/hero-slider.js', array('swiper-js'), '1.0.0', true);
    }
}
add_action('wp_enqueue_scripts', 'engine_dynamo_hero_scripts');