<?php
/**
 * Contact form email template
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Generate the contact form email content
 *
 * @param array $data Form submission data
 * @return string HTML email content
 */
function engine_dynamo_get_contact_email($data) {
    $content = '
    <div style="margin-bottom: 30px;">
        <h2 style="color: #2B6EF2; margin-bottom: 20px;">New Contact Form Submission</h2>
        
        <div class="info-box">
            <p><strong>From:</strong> ' . esc_html($data['name']) . ' (' . esc_html($data['email']) . ')</p>
            <p><strong>Subject:</strong> ' . esc_html($data['subject']) . '</p>
            <p><strong>Submitted:</strong> ' . current_time('F j, Y \a\t g:i a') . '</p>
        </div>

        <div style="margin-top: 30px;">
            <h3 style="color: #2B6EF2;">Message:</h3>
            <div style="background: #F7FAFC; padding: 20px; border-radius: 5px; margin-top: 10px;">
                ' . nl2br(esc_html($data['message'])) . '
            </div>
        </div>
    </div>

    <hr style="border: 0; border-top: 1px solid #E2E8F0; margin: 30px 0;">

    <div style="color: #718096; font-size: 13px;">
        <p>This message was sent from the contact form at ' . get_bloginfo('name') . ' (' . home_url() . ')</p>
        <p>IP: ' . sanitize_text_field($_SERVER['REMOTE_ADDR']) . '</p>
        <p>User Agent: ' . sanitize_text_field($_SERVER['HTTP_USER_AGENT']) . '</p>
    </div>';

    return $content;
}

/**
 * Generate the contact form auto-reply email content
 *
 * @param array $data Form submission data
 * @return string HTML email content
 */
function engine_dynamo_get_contact_autoreply($data) {
    $content = '
    <div style="margin-bottom: 30px;">
        <p>Dear ' . esc_html($data['name']) . ',</p>

        <p>Thank you for contacting ENGINE DYNAMO. We have received your message regarding:</p>
        
        <div class="info-box" style="margin: 20px 0;">
            <strong>' . esc_html($data['subject']) . '</strong>
        </div>

        <p>Our team will review your message and get back to you as soon as possible. We typically respond within 24-48 hours during business days.</p>

        <div style="margin: 30px 0; text-align: center;">
            <a href="' . esc_url(home_url('/')) . '" class="button" style="color: white; text-decoration: none;">
                Visit Our Website
            </a>
        </div>

        <div style="margin-top: 30px;">
            <p><strong>For your records, here is a copy of your message:</strong></p>
            <div class="info-box">
                ' . nl2br(esc_html($data['message'])) . '
            </div>
        </div>
    </div>

    <hr style="border: 0; border-top: 1px solid #E2E8F0; margin: 30px 0;">

    <div style="color: #718096; font-size: 13px;">
        <p>This is an automated response. Please do not reply to this email.</p>
    </div>';

    return $content;
}
