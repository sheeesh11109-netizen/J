<?php
/**
 * Contact form functionality
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Handle contact form submission
 *
 * @return array Response array with status and message
 */
function engine_dynamo_handle_contact_form() {
    // Load dependencies
    require_once get_template_directory() . '/inc/email-helpers.php';
    require_once get_template_directory() . '/inc/email-templates/contact.php';

    // Verify nonce
    if (!isset($_POST['contact_nonce']) || !wp_verify_nonce($_POST['contact_nonce'], 'engine_dynamo_contact_form')) {
        return array(
            'status' => 'error',
            'message' => 'Security verification failed. Please refresh the page and try again.'
        );
    }

    // Validate fields
    $required_fields = array('contact_name', 'contact_email', 'contact_subject', 'contact_message');
    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            return array(
                'status' => 'error',
                'message' => 'Please fill in all required fields.'
            );
        }
    }

    // Sanitize input
    $data = array(
        'name' => sanitize_text_field($_POST['contact_name']),
        'email' => sanitize_email($_POST['contact_email']),
        'subject' => sanitize_text_field($_POST['contact_subject']),
        'message' => sanitize_textarea_field($_POST['contact_message'])
    );

    // Validate email
    if (!is_email($data['email'])) {
        return array(
            'status' => 'error',
            'message' => 'Please enter a valid email address.'
        );
    }

    // Check for spam
    if (!empty($_POST['website']) || preg_match('/https?:\/\//i', $data['message'])) {
        return array(
            'status' => 'error',
            'message' => 'Your message appears to be spam.'
        );
    }

    // Rate limiting
    $ip = $_SERVER['REMOTE_ADDR'];
    $rate_limit_key = 'contact_form_' . md5($ip);
    if (get_transient($rate_limit_key)) {
        return array(
            'status' => 'error',
            'message' => 'Too many attempts. Please wait before trying again.'
        );
    }

    // Set rate limit
    set_transient($rate_limit_key, '1', HOUR_IN_SECONDS);

    // Prepare and send admin notification email
    $admin_email = get_option('admin_email');
    $site_name = get_bloginfo('name');
    
    $admin_subject = sprintf('[%s] New Contact Form Message: %s', $site_name, $data['subject']);
    $admin_content = engine_dynamo_get_contact_email($data);
    $admin_message = engine_dynamo_get_email_template($admin_content, 'New Contact Form Message');

    $admin_sent = engine_dynamo_send_email(
        $admin_email,
        $admin_subject,
        $admin_message,
        $data['name'],
        $data['email']
    );

    // Send auto-reply to user
    $autoreply_content = engine_dynamo_get_contact_autoreply($data);
    $autoreply_message = engine_dynamo_get_email_template(
        $autoreply_content,
        'Thank You for Contacting ' . $site_name
    );

    $autoreply_sent = engine_dynamo_send_email(
        $data['email'],
        'Thank you for your message',
        $autoreply_message
    );

    // Log any email failures
    if (!$admin_sent || !$autoreply_sent) {
        error_log(sprintf(
            '[ENGINE DYNAMO] Contact form email failure - Admin: %s, Autoreply: %s',
            $admin_sent ? 'sent' : 'failed',
            $autoreply_sent ? 'sent' : 'failed'
        ));
    }

    // Return success even if emails fail - we'll investigate via logs
    return array(
        'status' => 'success',
        'message' => 'Thank you! Your message has been sent successfully.'
    );
}

/**
 * AJAX handler for contact form submissions
 */
function engine_dynamo_ajax_contact_form() {
    $response = engine_dynamo_handle_contact_form();

    if ($response['status'] === 'success') {
        wp_send_json_success($response);
    } else {
        wp_send_json_error($response);
    }
}
add_action('wp_ajax_engine_dynamo_contact', 'engine_dynamo_ajax_contact_form');
add_action('wp_ajax_nopriv_engine_dynamo_contact', 'engine_dynamo_ajax_contact_form');
