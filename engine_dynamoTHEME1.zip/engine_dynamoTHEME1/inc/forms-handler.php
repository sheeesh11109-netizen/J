<?php
/**
 * Newsletter and Contact Form Handler
 * 
 * @package EngineDynamo
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Initialize form handlers and create database tables
 */
class ED_Forms_Handler {
    private static $instance = null;
    private $subscribers_table;
    private $contact_table;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        global $wpdb;
        $this->subscribers_table = $wpdb->prefix . 'newsletter_subscribers';
        $this->contact_table = $wpdb->prefix . 'contact_messages';

        // Initialize database tables
        register_activation_hook(__FILE__, array($this, 'create_tables'));

        // AJAX handlers
        add_action('wp_ajax_ed_newsletter_subscribe', array($this, 'handle_newsletter_subscription'));
        add_action('wp_ajax_nopriv_ed_newsletter_subscribe', array($this, 'handle_newsletter_subscription'));
        add_action('wp_ajax_ed_contact_submit', array($this, 'handle_contact_submission'));
        add_action('wp_ajax_nopriv_ed_contact_submit', array($this, 'handle_contact_submission'));

        // Email verification handler
        add_action('init', array($this, 'handle_email_verification'));

        // Add form nonces to footer
        add_action('wp_footer', array($this, 'add_form_nonces'));
    }

    /**
     * Create necessary database tables
     */
    public function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        // Newsletter subscribers table
        $sql1 = "CREATE TABLE IF NOT EXISTS {$this->subscribers_table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            email varchar(100) NOT NULL,
            token varchar(36) NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'pending',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY email (email),
            KEY token (token)
        ) $charset_collate;";

        // Contact messages table
        $sql2 = "CREATE TABLE IF NOT EXISTS {$this->contact_table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            name varchar(100) NOT NULL,
            email varchar(100) NOT NULL,
            message text NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql1);
        dbDelta($sql2);
    }

    /**
     * Handle newsletter subscription
     */
    public function handle_newsletter_subscription() {
        check_ajax_referer('ed_forms_nonce', 'nonce');

        $email = sanitize_email($_POST['email']);
        if (!is_email($email)) {
            wp_send_json_error(array('message' => 'Please enter a valid email address.'));
            return;
        }

        global $wpdb;
        
        // Check if email exists
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->subscribers_table} WHERE email = %s",
            $email
        ));

        if ($existing) {
            if ($existing->status === 'verified') {
                wp_send_json_error(array('message' => 'This email is already subscribed!'));
                return;
            }
            if ($existing->status === 'pending') {
                // Resend verification email
                $this->send_verification_email($email, $existing->token);
                wp_send_json_error(array('message' => 'Please check your email to verify your subscription.'));
                return;
            }
        }

        // Generate token and insert subscriber
        $token = wp_generate_uuid4();
        
        $result = $wpdb->insert(
            $this->subscribers_table,
            array(
                'email' => $email,
                'token' => $token,
                'status' => 'pending',
                'created_at' => current_time('mysql')
            ),
            array('%s', '%s', '%s', '%s')
        );

        if (!$result) {
            wp_send_json_error(array('message' => 'Failed to process subscription. Please try again.'));
            return;
        }

        // Send verification email
        $sent = $this->send_verification_email($email, $token);
        
        if ($sent) {
            wp_send_json_success(array('message' => 'Please check your email to verify your subscription.'));
        } else {
            wp_send_json_error(array('message' => 'Failed to send verification email. Please try again.'));
        }
    }

    /**
     * Send verification email
     */
    private function send_verification_email($email, $token) {
        $verify_url = add_query_arg('verify_email', $token, home_url('/'));
        
        $subject = get_bloginfo('name') . ' - Verify your subscription';
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . get_bloginfo('name') . ' <noreply@' . parse_url(home_url(), PHP_URL_HOST) . '>'
        );
        
        $message = sprintf(
            '<!DOCTYPE html>
            <html>
            <body>
                <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                    <h2>Verify Your Email Address</h2>
                    <p>Thank you for subscribing to our newsletter! Please click the link below to verify your email:</p>
                    <p style="text-align: center">
                        <a href="%s" style="display: inline-block; padding: 12px 24px; background-color: #2B6EF2; color: white; text-decoration: none; border-radius: 4px;">
                            Verify My Subscription
                        </a>
                    </p>
                    <p>Or copy and paste this URL into your browser:</p>
                    <p>%s</p>
                </div>
            </body>
            </html>',
            esc_url($verify_url),
            esc_url($verify_url)
        , esc_html(get_bloginfo('name'))
        );

        return wp_mail($email, $subject, $message, $headers);
    }

    /**
     * Handle email verification
     */
    public function handle_email_verification() {
        if (!isset($_GET['verify_email'])) {
            return;
        }

        $token = sanitize_text_field($_GET['verify_email']);
        global $wpdb;

        // Find and verify subscriber
        $subscriber = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->subscribers_table} WHERE token = %s AND status = 'pending'",
            $token
        ));

        $message = '';
        if ($subscriber) {
            $wpdb->update(
                $this->subscribers_table,
                array('status' => 'verified'),
                array('id' => $subscriber->id),
                array('%s'),
                array('%d')
            );
            $message = '✅ You\'re now subscribed to ' . get_bloginfo('name') . '!';
        } else {
            $message = '❌ Verification failed or expired.';
        }

        // Show message in footer with clear styling for both success and error states
        $type = (strpos($message, '✅') !== false) ? 'success' : 'error';
        add_action('wp_footer', function() use ($message, $type) {
            $bg = ($type === 'success') ? '#2ecc71' : '#e74c3c';
            $icon = ($type === 'success') ? '✅' : '❌';
            echo '<div class="newsletter-verification-container" '
                . 'style="position: fixed; top: 100px; left: 50%; transform: translateX(-50%); '
                . 'z-index: 9999; max-width: 520px; padding: 14px 20px; background: ' . $bg . '; '
                . 'color: #ffffff; border-radius: 6px; box-shadow: 0 6px 20px rgba(0,0,0,0.15); '
                . 'font-weight: 600; text-align: center; font-size: 15px;">'
                . esc_html($message) . '</div>';
        });
    }

    /**
     * Handle contact form submission
     */
    public function handle_contact_submission() {
        check_ajax_referer('ed_forms_nonce', 'nonce');

        $name = sanitize_text_field($_POST['name']);
        $email = sanitize_email($_POST['email']);
        $message = wp_kses_post($_POST['message']);

        // Validation
        if (empty($name) || empty($email) || empty($message)) {
            wp_send_json_error(array('message' => 'Please fill in all fields.'));
            return;
        }

        if (!is_email($email)) {
            wp_send_json_error(array('message' => 'Please enter a valid email address.'));
            return;
        }

        global $wpdb;

        // Store in database
        $result = $wpdb->insert(
            $this->contact_table,
            array(
                'name' => $name,
                'email' => $email,
                'message' => $message,
                'created_at' => current_time('mysql')
            ),
            array('%s', '%s', '%s', '%s')
        );

        if (!$result) {
            wp_send_json_error(array('message' => 'Failed to save your message. Please try again.'));
            return;
        }

        // Send email notification
        $to = 'info@enginedynamo.com';
        $subject = get_bloginfo('name') . ' - New Contact Message';
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $name . ' <' . $email . '>',
            'Reply-To: ' . $email
        );

        $email_message = sprintf(
            '<!DOCTYPE html>
            <html>
            <body>
                <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                    <h2>New Contact Form Message</h2>
                    <p><strong>From:</strong> %s &lt;%s&gt;</p>
                    <div style="background: #f5f5f5; padding: 15px; border-radius: 4px;">
                        %s
                    </div>
                </div>
            </body>
            </html>',
            esc_html($name),
            esc_html($email),
            nl2br(esc_html($message))
        );

        $sent = wp_mail($to, $subject, $email_message, $headers);

        if ($sent) {
            wp_send_json_success(array('message' => 'Your message has been sent successfully!'));
        } else {
            wp_send_json_error(array('message' => 'Failed to send message. Please try again.'));
        }
    }

    /**
     * Add nonces to footer
     */
    public function add_form_nonces() {
        $nonce = wp_create_nonce('ed_forms_nonce');
        ?>
        <script>
        window.edFormsNonce = '<?php echo $nonce; ?>';
        // Ensure front-end AJAX URL is available for fetch() calls (some themes/plugins
        // or older WP setups don't expose `ajaxurl` on the front-end). Set a safe
        // fallback here so our JS uses the correct admin-ajax endpoint.
        if (typeof ajaxurl === 'undefined') {
            window.ajaxurl = '<?php echo esc_url(admin_url('admin-ajax.php')); ?>';
        }

        document.addEventListener('DOMContentLoaded', function() {
            // Newsletter form handling
            document.querySelectorAll('.newsletter-form').forEach(form => {
                form.addEventListener('submit', async function(e) {
                    e.preventDefault();
                    const email = this.querySelector('input[type="email"]').value;
                    const data = new FormData();
                    data.append('action', 'ed_newsletter_subscribe');
                    data.append('email', email);
                    data.append('nonce', window.edFormsNonce);

                    try {
                        const response = await fetch(ajaxurl, {
                            method: 'POST',
                            credentials: 'same-origin',
                            body: data
                        });
                        const result = await response.json();
                        alert(result.data.message);
                        if (result.success) this.reset();
                    } catch (error) {
                        alert('An error occurred. Please try again.');
                    }
                });
            });

            // Contact form handling
            document.querySelectorAll('.contact-form').forEach(form => {
                form.addEventListener('submit', async function(e) {
                    e.preventDefault();
                    const data = new FormData();
                    data.append('action', 'ed_contact_submit');
                    data.append('name', this.querySelector('input[name="name"]').value);
                    data.append('email', this.querySelector('input[name="email"]').value);
                    data.append('message', this.querySelector('textarea[name="message"]').value);
                    data.append('nonce', window.edFormsNonce);

                    try {
                        const response = await fetch(ajaxurl, {
                            method: 'POST',
                            credentials: 'same-origin',
                            body: data
                        });
                        const result = await response.json();
                        alert(result.data.message);
                        if (result.success) this.reset();
                    } catch (error) {
                        alert('An error occurred. Please try again.');
                    }
                });
            });
        });
        </script>
        <?php
    }
}

// Initialize the forms handler
ED_Forms_Handler::get_instance();