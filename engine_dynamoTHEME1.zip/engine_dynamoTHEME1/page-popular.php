<?php
/**
 * Template Name: Popular Posts
 *
 * A simple page that lists posts ordered by a 'post_views' meta key.
 * If your theme/plugin stores views under a different meta key, adjust
 * the 'meta_key' value accordingly.
 */

get_header();
?>

<main id="primary" class="site-main">
    <div class="container">
        <header class="page-header">
            <h1 class="page-title">Popular Posts</h1>
            <p class="page-description">Posts ordered by view count.</p>
        </header>

        <div class="posts-grid" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 2rem; max-width: 1200px; margin: 0 auto; padding: 0 20px;">
            <?php
            // Query posts ordered by meta key 'post_views_count' (engine_dynamo functions use this key).
            $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

            $popular = new WP_Query(array(
                'post_type'      => 'post',
                'posts_per_page' => 9,
                'paged'          => $paged,
                'post_status'    => 'publish',
                'meta_key'       => 'post_views_count',
                'orderby'        => 'meta_value_num',
                'order'          => 'DESC',
            ));

            if ($popular->have_posts()) :
                while ($popular->have_posts()) : $popular->the_post();
                    // Use theme helper which initializes the meta if missing
                    $views = intval(function_exists('engine_dynamo_get_post_views') ? engine_dynamo_get_post_views(get_the_ID()) : get_post_meta(get_the_ID(), 'post_views_count', true));
            ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class('post-card'); ?>>
                        <div class="post-thumbnail">
                            <a href="<?php the_permalink(); ?>">
                                <?php if (has_post_thumbnail()) : ?>
                                    <?php the_post_thumbnail('article-thumbnail'); ?>
                                <?php else : ?>
                                    <div class="placeholder-image">
                                        <span class="placeholder-icon">🚗</span>
                                    </div>
                                <?php endif; ?>
                            </a>
                        </div>

                        <div class="post-content">
                            <div class="post-meta">
                                <span class="post-date"><?php echo get_the_date(); ?></span>
                                <span class="post-views">Views: <?php echo $views; ?></span>
                            </div>

                            <h2 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            <div class="post-excerpt"><?php echo wp_trim_words(get_the_excerpt(), 20, '...'); ?></div>
                            <a href="<?php the_permalink(); ?>" class="read-more-btn">Read More</a>
                        </div>
                    </article>
            <?php
                endwhile;

                // Pagination
                $big = 999999999;
                echo paginate_links(array(
                    'base'    => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                    'format'  => '?paged=%#%',
                    'current' => max(1, $paged),
                    'total'   => $popular->max_num_pages,
                    'type'    => 'list',
                ));

                wp_reset_postdata();
            else :
            ?>
                <div class="no-posts">
                    <div class="no-posts-icon">📝</div>
                    <h2>No Popular Posts Found</h2>
                    <p>There are no posts with view counts yet.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php get_footer(); ?>
<?php
/**
 * Template Name: Popular Posts Page
 * The template for displaying popular posts by view count
 *
 * @package EngineDynamo
 */

get_header(); ?>

<main id="primary" class="site-main">
    <div class="container">
        <div class="content-wrapper">
            
            <!-- Popular Posts Header -->
            <header class="page-header">
                <h1 class="page-title">Popular Posts</h1>
                <p class="page-description">Discover our most read and highly rated automotive articles.</p>
            </header>

            <div class="blog-layout">
                <!-- Main Content -->
                <div class="main-content">
                    
                    <!-- Popular Posts Grid -->
                    <div class="posts-grid">
                        <?php
                        $popular_posts = new WP_Query(array(
                            'post_type' => 'post',
                            'posts_per_page' => 12,
                            'meta_key' => '_post_views',
                            'orderby' => 'meta_value_num',
                            'order' => 'DESC',
                            'post_status' => 'publish'
                        ));
                        
                        if ($popular_posts->have_posts()) : ?>
                            <?php while ($popular_posts->have_posts()) : $popular_posts->the_post(); ?>
                                <article id="post-<?php the_ID(); ?>" <?php post_class('post-card'); ?>>
                                    
                                    <?php if (has_post_thumbnail()) : ?>
                                        <div class="post-thumbnail">
                                            <a href="<?php the_permalink(); ?>">
                                                <?php the_post_thumbnail('article-thumbnail'); ?>
                                            </a>
                                        </div>
                                    <?php else : ?>
                                        <div class="post-thumbnail">
                                            <a href="<?php the_permalink(); ?>">
                                                <div class="placeholder-image">
                                                    <span class="placeholder-icon">🚗</span>
                                                    <span class="placeholder-text">Automotive</span>
                                                </div>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <div class="post-content">
                                        <div class="post-meta">
                                            <span class="post-date"><?php echo get_the_date(); ?></span>
                                            <span class="post-category"><?php the_category(', '); ?></span>
                                            <span class="post-author">By <?php the_author(); ?></span>
                                        </div>
                                        
                                        <h2 class="post-title">
                                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                        </h2>
                                        
                                        <div class="post-excerpt">
                                            <?php the_excerpt(); ?>
                                        </div>
                                        
                                        <div class="post-stats">
                                            <?php
                                            $views = get_post_meta(get_the_ID(), '_post_views', true);
                                            $views = $views ? $views : 0;
                                            $average_rating = get_post_meta(get_the_ID(), '_average_rating', true);
                                            $rating_count = count(get_post_meta(get_the_ID(), '_post_ratings', true));
                                            ?>
                                            <div class="stat-item">
                                                <span class="stat-icon">👁️</span>
                                                <span class="stat-text"><?php echo $views; ?> views</span>
                                            </div>
                                            <?php if ($average_rating) : ?>
                                                <div class="stat-item">
                                                    <span class="stat-icon">⭐</span>
                                                    <span class="stat-text"><?php echo round($average_rating, 1); ?> (<?php echo $rating_count; ?> ratings)</span>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <a href="<?php the_permalink(); ?>" class="read-more-btn">Read More</a>
                                    </div>
                                </article>
                            <?php endwhile; ?>

                            <!-- Pagination -->
                            <?php
                            the_posts_pagination(array(
                                'prev_text' => esc_html__('Previous', 'engine-dynamo'),
                                'next_text' => esc_html__('Next', 'engine-dynamo'),
                                'mid_size' => 2,
                            ));
                            ?>

                        <?php else : ?>
                            
                            <!-- No Posts -->
                            <div class="no-posts">
                                <h2><?php esc_html_e('No popular posts found', 'engine-dynamo'); ?></h2>
                                <p><?php esc_html_e('Sorry, no popular posts were found.', 'engine-dynamo'); ?></p>
                                <a href="<?php echo home_url(); ?>" class="btn btn-primary">Go Home</a>
                            </div>

                        <?php endif; ?>
                    </div>

                </div>

                <!-- Sidebar -->
                <aside class="sidebar">
                    <div class="widget">
                        <h3 class="widget-title">About Popular Posts</h3>
                        <div class="widget-description">
                            <p>These are our most read and highly rated articles, determined by view count and user ratings.</p>
                        </div>
                    </div>

                    <div class="widget">
                        <h3 class="widget-title">Top Categories</h3>
                        <ul class="categories-list">
                            <?php
                            wp_list_categories(array(
                                'title_li' => '',
                                'show_count' => true,
                                'orderby' => 'count',
                                'order' => 'DESC',
                                'number' => 5
                            ));
                            ?>
                        </ul>
                    </div>

                    <div class="widget">
                        <h3 class="widget-title">Newsletter</h3>
                        <div class="widget-description">
                            <p>Subscribe to get notified about our most popular content.</p>
                        </div>
                        <form class="newsletter-form">
                            <div class="input-group">
                                <input type="email" class="email-input" placeholder="Your email address" required>
                                <button type="submit" class="subscribe-btn">Subscribe</button>
                            </div>
                        </form>
                    </div>
                </aside>
            </div>

        </div>
    </div>
</main>

<?php
get_footer();
