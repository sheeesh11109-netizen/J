<?php
/**
 * Template part for displaying hero slider
 */
?>
<section id="hero-section" class="hero-slider">
  <!-- Overlay -->
  <div class="hero-overlay"></div>

  <!-- Slider -->
  <div class="swiper heroSwiper">
    <div class="swiper-wrapper">
      <div class="swiper-slide">
        <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/hero-car-1.jpg" alt="Performance Cars">
      </div>
      <div class="swiper-slide">
        <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/hero-car-2.jpg" alt="High Performance">
      </div>
      <div class="swiper-slide">
        <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/hero-car-3.jpg" alt="Luxury Cars">
      </div>
      <div class="swiper-slide">
        <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/hero-car-4.jpg" alt="Sports Cars">
      </div>
      <div class="swiper-slide">
        <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/hero-car-5.jpg" alt="Classic Cars">
      </div>
      <div class="swiper-slide">
        <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/hero-car-6.jpg" alt="Super Cars">
      </div>
    </div>
    <div class="swiper-pagination"></div>
  </div>

  <!-- Content -->
  <div class="hero-content">
    <h1 class="engine-dynamo">
      <span class="engine">ENGINE</span> <span class="dynamo">DYNAMO</span>
    </h1>
    <p class="slide-description">Premium automotive writing — deep reviews, real tips.</p>
    <p class="slide-description">High-performance guides, buying advice, and maintenance tips — delivered with cinematic design and modern interaction.</p>
    <div class="hero-buttons">
      <a href="<?php echo esc_url(home_url('/blog')); ?>" class="slide-button primary">Latest Posts</a>
      <a href="<?php echo esc_url(home_url('/about')); ?>" class="slide-button secondary">About Us</a>
    </div>
  </div>
</section>