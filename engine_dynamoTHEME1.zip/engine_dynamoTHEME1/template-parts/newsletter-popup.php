<?php
/**
 * Newsletter Popup Template
 * 
 * Enhanced with modern design, improved accessibility, and smart timing controls
 */
?>
<div id="newsletter-popup" class="newsletter-popup">
    <div class="newsletter-popup-content" role="dialog" aria-modal="true" aria-labelledby="newsletter-title">
        <button class="close-popup" aria-label="Close newsletter popup" title="Close">
            <svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" focusable="false">
                <path fill="currentColor" d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
            </svg>
        </button>
        
        <div class="popup-header">
            <h3 id="newsletter-title">Stay in the Loop!</h3>
            <p>Get exclusive automotive insights, maintenance tips, and industry updates delivered straight to your inbox.</p>
        </div>

        <form id="popup-newsletter-form" class="popup-newsletter-form" method="post" novalidate>
            <?php wp_nonce_field('engine_dynamo_newsletter', 'newsletter_popup_nonce'); ?>
            
            <div class="form-group">
                <input 
                    type="email" 
                    id="popup-email"
                    name="email" 
                    placeholder="Enter your email address"
                    required 
                    pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$"
                    aria-describedby="email-validation"
                />
                <span id="email-validation" class="validation-message" aria-live="polite"></span>
            </div>

            <div class="checkbox-wrapper">
                <input 
                    type="checkbox" 
                    id="popup-privacy-consent" 
                    name="privacy_consent" 
                    required
                />
                <label for="popup-privacy-consent">
                    I agree to receive newsletters and accept the 
                    <a href="/privacy-policy">privacy policy</a>.
                </label>
            </div>

            <button type="submit" class="subscribe-btn">
                Subscribe Now
            </button>

            <div class="newsletter-feedback" role="status" aria-live="polite"></div>
        </form>

        <div class="newsletter-footer">
            <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
                <path fill="currentColor" d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/>
            </svg>
            <p>Your privacy is important to us. You can unsubscribe at any time.</p>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const popup = document.getElementById('newsletter-popup');
    if (!popup) return;

    const form = document.getElementById('popup-newsletter-form');
    const emailInput = document.getElementById('popup-email');
    const submitBtn = form.querySelector('button[type="submit"]');
    const feedbackDiv = form.querySelector('.newsletter-feedback');
    const validationSpan = document.getElementById('email-validation');
    
    // Cookie and storage handling
    const COOKIE_NAMES = {
        SUBSCRIBED: 'ed_newsletter_subscribed',
        DISMISSED: 'ed_newsletter_dismissed',
        LAST_SHOWN: 'ed_newsletter_last_shown'
    };

    function setCookie(name, value, days) {
        const date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        document.cookie = `${name}=${value};expires=${date.toUTCString()};path=/;SameSite=Lax`;
    }

    function getCookie(name) {
        const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
        return match ? match[2] : null;
    }

    // Mark returning visitor on first page load so popup targets returning users only
    if (!getCookie('_returning_visitor')) {
        // Set for 1 year
        setCookie('_returning_visitor', 'true', 365);
    }

    // Popup visibility control
    function showPopup() {
        if (popup.classList.contains('show')) return;
        popup.style.display = 'flex';
        requestAnimationFrame(() => popup.classList.add('show'));
        // Record last shown timestamp and keep it for 30 days
        setCookie(COOKIE_NAMES.LAST_SHOWN, Date.now(), 30);
    }

    function hidePopup() {
        popup.classList.remove('show');
        setTimeout(() => popup.style.display = 'none', 300);
    }

    // Show popup conditions
    function shouldShowPopup() {
        const hasSubscribed = getCookie(COOKIE_NAMES.SUBSCRIBED);
        const hasDismissed = getCookie(COOKIE_NAMES.DISMISSED);
        const lastShown = getCookie(COOKIE_NAMES.LAST_SHOWN);
        const thirtyDays = 30 * 24 * 60 * 60 * 1000; // Increased to 30 days

        // Don't show on mobile devices
        const isMobile = window.innerWidth < 768;
        
        // Check if user is a returning visitor
        const isReturningVisitor = getCookie('_returning_visitor');

        return !isMobile && // Don't show on mobile
               !hasSubscribed && 
               !hasDismissed && 
               isReturningVisitor && // Only show to returning visitors
               (!lastShown || (Date.now() - parseInt(lastShown)) > thirtyDays);
    }

    // Initialize popup behavior
    if (shouldShowPopup()) {
        let hasShown = false;
        
        // Show after 60 seconds (increased from 30)
        const timer = setTimeout(() => {
            if (!hasShown) showPopup();
        }, 60000);

        // Or show at 90% scroll (increased from 75%)
        const scrollHandler = () => {
            if (hasShown) return;
            
            const scrolled = (window.scrollY + window.innerHeight) / document.documentElement.scrollHeight;
            if (scrolled > 0.9) {
                showPopup();
                hasShown = true;
                clearTimeout(timer);
                window.removeEventListener('scroll', scrollHandler);
            }
        };

        window.addEventListener('scroll', scrollHandler, { passive: true });
    }

    // Close button handler
    popup.querySelector('.close-popup').addEventListener('click', () => {
        hidePopup();
        // Respect dismissal for 30 days
        setCookie(COOKIE_NAMES.DISMISSED, 'true', 30);
    });

    // Click outside to close
    popup.addEventListener('click', (e) => {
        if (e.target === popup) {
            hidePopup();
            // Respect dismissal for 30 days
            setCookie(COOKIE_NAMES.DISMISSED, 'true', 30);
        }
    });

    // Form validation
    emailInput.addEventListener('input', function() {
        const isValid = emailInput.checkValidity();
        if (isValid) {
            validationSpan.textContent = '';
            emailInput.classList.remove('invalid');
        } else {
            validationSpan.textContent = 'Please enter a valid email address';
            emailInput.classList.add('invalid');
        }
    });

    // Form submission
    form.addEventListener('submit', async function(e) {
        e.preventDefault();

        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }

        const formData = new FormData(form);
        formData.append('action', 'engine_dynamo_newsletter');

        submitBtn.disabled = true;
        submitBtn.classList.add('loading');

        try {
            const response = await fetch(engineDynamoAjax.ajaxUrl, {
                method: 'POST',
                body: formData,
                credentials: 'same-origin'
            });

            const data = await response.json();

            if (data.success) {
                feedbackDiv.innerHTML = `
                    <div class="newsletter-success">
                        <svg viewBox="0 0 24 24" width="24" height="24">
                            <path fill="currentColor" d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                        </svg>
                        <span class="newsletter-success-text">${data.data.message}</span>
                        <button type="button" class="newsletter-dismiss" aria-label="Dismiss">Dismiss</button>
                    </div>
                `;
                
                form.reset();
                setCookie(COOKIE_NAMES.SUBSCRIBED, 'true', 365);
                
                // Add dismiss handler on success so user can explicitly close the confirmation
                const dismissBtn = feedbackDiv.querySelector('.newsletter-dismiss');
                if (dismissBtn) {
                    dismissBtn.addEventListener('click', () => {
                        // hide only the feedback if inside inline form, otherwise hide popup
                        if (popup) hidePopup();
                        feedbackDiv.innerHTML = '';
                    });
                }
                // Also auto-close after a short wait for convenience
                setTimeout(() => { if (popup) hidePopup(); }, 3000);
                
                // Track conversion if GA available
                if (typeof gtag !== 'undefined') {
                    gtag('event', 'newsletter_subscription', {
                        event_category: 'engagement',
                        event_label: 'Newsletter Popup'
                    });
                }
            } else {
                feedbackDiv.innerHTML = `
                    <div class="newsletter-error">
                        <svg viewBox="0 0 24 24" width="24" height="24">
                            <path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>
                        </svg>
                        <span>${data.data.message}</span>
                    </div>
                `;
            }
        } catch (error) {
            feedbackDiv.innerHTML = `
                <div class="newsletter-error">
                    <svg viewBox="0 0 24 24" width="24" height="24">
                        <path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>
                    </svg>
                    <span>An error occurred. Please try again later.</span>
                </div>
            `;
        } finally {
            submitBtn.disabled = false;
            submitBtn.classList.remove('loading');
        }
    });

    // Handle escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && popup.classList.contains('show')) {
            hidePopup();
            // Respect dismissal for 30 days
            setCookie(COOKIE_NAMES.DISMISSED, 'true', 30);
        }
    });
});
</script>
<script>
// Attach a dismiss button to any newsletter verification message that might be rendered
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.newsletter-verification-message').forEach(function(msg) {
        if (msg.querySelector('.newsletter-dismiss')) return; // already has dismiss
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'newsletter-dismiss verification-dismiss';
        btn.textContent = 'Dismiss';
        btn.style.marginLeft = '12px';
        btn.addEventListener('click', function() {
            msg.style.display = 'none';
        });
        // append to the message (to the right)
        msg.appendChild(btn);
    });
});
</script>
