<?php
/**
 * The template for displaying the Privacy Policy page
 *
 * @package EngineDynamo
 */

get_header(); ?>

<main id="primary" class="site-main">
    <div class="container">
        
        <!-- Privacy Policy Header -->
        <header class="page-header">
            <h1 class="page-title">Privacy Policy</h1>
            <p class="page-description">Your privacy is important to us. This policy explains how we collect, use, and protect your information.</p>
        </header>

        <!-- Breadcrumb Navigation -->
        <nav class="breadcrumb">
            <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
            <span class="breadcrumb-separator">›</span>
            <span class="breadcrumb-current">Privacy Policy</span>
        </nav>

        <div class="legal-content">
            
            <!-- Introduction -->
            <section class="legal-section">
                <h2>1. Information We Collect</h2>
                <p>We collect information you provide directly to us, such as when you create an account, subscribe to our newsletter, or contact us for support.</p>
                <h3>Personal Information</h3>
                <ul>
                    <li>Name and email address when you subscribe to our newsletter</li>
                    <li>Contact information when you reach out to us</li>
                    <li>Comments and feedback you provide on our articles</li>
                </ul>
                <h3>Automatically Collected Information</h3>
                <ul>
                    <li>IP address and browser information</li>
                    <li>Pages visited and time spent on our site</li>
                    <li>Referring website information</li>
                    <li>Device and operating system information</li>
                </ul>
            </section>

            <!-- How We Use Information -->
            <section class="legal-section">
                <h2>2. How We Use Your Information</h2>
                <p>We use the information we collect to:</p>
                <ul>
                    <li>Provide, maintain, and improve our services</li>
                    <li>Send you newsletters and updates (with your consent)</li>
                    <li>Respond to your comments and questions</li>
                    <li>Analyze how our website is used to improve user experience</li>
                    <li>Detect, prevent, and address technical issues</li>
                </ul>
            </section>

            <!-- Information Sharing -->
            <section class="legal-section">
                <h2>3. Information Sharing and Disclosure</h2>
                <p>We do not sell, trade, or otherwise transfer your personal information to third parties without your consent, except in the following circumstances:</p>
                <ul>
                    <li><strong>Service Providers:</strong> We may share information with trusted third parties who assist us in operating our website</li>
                    <li><strong>Legal Requirements:</strong> We may disclose information if required by law or to protect our rights</li>
                    <li><strong>Business Transfers:</strong> In the event of a merger or acquisition, your information may be transferred</li>
                </ul>
            </section>

            <!-- Cookies -->
            <section class="legal-section">
                <h2>4. Cookies and Tracking Technologies</h2>
                <p>We use cookies and similar tracking technologies to enhance your experience on our website. Cookies are small files that a site or its service provider transfers to your computer's hard drive through your web browser.</p>
                <h3>Types of Cookies We Use:</h3>
                <ul>
                    <li><strong>Essential Cookies:</strong> Necessary for the website to function properly</li>
                    <li><strong>Analytics Cookies:</strong> Help us understand how visitors interact with our website</li>
                    <li><strong>Functional Cookies:</strong> Remember your preferences and settings</li>
                </ul>
                <p>You can choose to disable cookies through your browser settings, but this may affect the functionality of our website.</p>
            </section>

            <!-- Data Security -->
            <section class="legal-section">
                <h2>5. Data Security</h2>
                <p>We implement appropriate security measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction. However, no method of transmission over the internet or electronic storage is 100% secure.</p>
                <p>We use industry-standard security protocols and regularly review our security practices to ensure your information is protected.</p>
            </section>

            <!-- Your Rights -->
            <section class="legal-section">
                <h2>6. Your Rights and Choices</h2>
                <p>You have the right to:</p>
                <ul>
                    <li><strong>Access:</strong> Request a copy of the personal information we hold about you</li>
                    <li><strong>Correction:</strong> Request correction of inaccurate personal information</li>
                    <li><strong>Deletion:</strong> Request deletion of your personal information</li>
                    <li><strong>Opt-out:</strong> Unsubscribe from our newsletters at any time</li>
                    <li><strong>Data Portability:</strong> Request transfer of your data to another service</li>
                </ul>
                <p>To exercise these rights, please visit our <a href="<?php echo esc_url( home_url( '/contact' ) ); ?>">Contact</a> page or use the website's contact form.</p>
            </section>

            <!-- Third-Party Services -->
            <section class="legal-section">
                <h2>7. Third-Party Services</h2>
                <p>Our website may contain links to third-party websites or services. We are not responsible for the privacy practices of these third parties. We encourage you to read their privacy policies before providing any personal information.</p>
                <h3>Third-Party Services We Use:</h3>
                <ul>
                    <li><strong>Google Analytics:</strong> For website analytics and performance monitoring</li>
                    <li><strong>Social Media Platforms:</strong> For social sharing and engagement</li>
                    <li><strong>Email Services:</strong> For newsletter delivery and communication</li>
                </ul>
            </section>

            <!-- Children's Privacy -->
            <section class="legal-section">
                <h2>8. Children's Privacy</h2>
                <p>Our services are not directed to children under 13 years of age. We do not knowingly collect personal information from children under 13. If we become aware that we have collected personal information from a child under 13, we will take steps to delete such information.</p>
            </section>

            <!-- International Transfers -->
            <section class="legal-section">
                <h2>9. International Data Transfers</h2>
                <p>Your information may be transferred to and processed in countries other than your own. We ensure that such transfers comply with applicable data protection laws and implement appropriate safeguards to protect your information.</p>
            </section>

            <!-- Changes to Privacy Policy -->
            <section class="legal-section">
                <h2>10. Changes to This Privacy Policy</h2>
                <p>We may update this privacy policy from time to time. We will notify you of any changes by posting the new privacy policy on this page and updating the "Last updated" date.</p>
                <p>We encourage you to review this privacy policy periodically for any changes.</p>
            </section>

            <!-- Contact details removed -->

            <!-- Last Updated -->
            <section class="legal-section">
                <p class="last-updated"><strong>Last updated:</strong> <?php echo date('F j, Y'); ?></p>
            </section>
            
        </div>
        
    </div>
</main>

<?php
get_footer();
