<?php
/**
 * Template Name: Blog (All Posts Archive)
 *
 * A simple page template that displays all posts in a grid and uses the
 * same post-card markup as the homepage so styling is consistent.
 */

get_header();
?>

<main id="primary" class="site-main">
    <div class="container">
        <header class="page-header">
            <h1 class="page-title">All Articles</h1>
            <p class="page-description">An archive of all posts — latest first.</p>
        </header>

        <div class="posts-grid">
            <?php
            // Use the 'paged' query var (standard WP) instead of 'page'
            $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

            $all_posts = new WP_Query(array(
                'post_type'      => 'post',
                'posts_per_page' => 9,
                'paged'          => $paged,
                'post_status'    => 'publish',
                'orderby'        => 'date',
                'order'          => 'DESC'
            ));

            if ($all_posts->have_posts()) :
                while ($all_posts->have_posts()) : $all_posts->the_post();
            ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class('post-card'); ?>>
                        <div class="post-thumbnail">
                            <a href="<?php the_permalink(); ?>">
                                <?php if (has_post_thumbnail()) : ?>
                                    <?php the_post_thumbnail('article-thumbnail'); ?>
                                <?php else : ?>
                                    <div class="placeholder-image">
                                        <span class="placeholder-icon">🚗</span>
                                        <span class="placeholder-text">Automotive</span>
                                    </div>
                                <?php endif; ?>
                            </a>
                        </div>

                        <div class="post-content">
                            <div class="post-meta">
                                <span class="post-date"><?php echo get_the_date(); ?></span>
                                <span class="post-category"><?php the_category(', '); ?></span>
                                <span class="reading-time"><?php echo function_exists('engine_dynamo_display_reading_time') ? engine_dynamo_display_reading_time() : ''; ?></span>
                            </div>

                            <h2 class="post-title">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h2>

                            <div class="post-excerpt">
                                <?php echo wp_trim_words(get_the_excerpt(), 20, '...'); ?>
                            </div>

                            <a href="<?php the_permalink(); ?>" class="read-more-btn">Read More</a>
                        </div>
                    </article>
            <?php
                endwhile;

                // Pagination (works with pretty or non-pretty permalinks)
                $big = 999999999; // need an unlikely integer
                echo paginate_links(array(
                    'base'      => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                    'format'    => '?paged=%#%',
                    'current'   => max(1, $paged),
                    'total'     => $all_posts->max_num_pages,
                    'prev_text' => '&laquo; Previous',
                    'next_text' => 'Next &raquo;',
                    'type'      => 'list',
                ));

                wp_reset_postdata();

            else :
            ?>
                <div class="no-posts">
                    <div class="no-posts-icon">📝</div>
                    <h2>No Posts Found</h2>
                    <p>We're working on creating amazing automotive content for you. Check back soon!</p>
                    <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-primary">Go Home</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php get_footer(); ?>

