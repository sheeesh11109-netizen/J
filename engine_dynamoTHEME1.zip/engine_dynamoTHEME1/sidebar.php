<?php
/**
 * The sidebar containing the main widget area
 *
 * @package EngineDynamo
 */

if (!is_active_sidebar('sidebar-1')) {
    return;
}
?>

<aside id="secondary" class="widget-area">
    <?php dynamic_sidebar('sidebar-1'); ?>
    
    <!-- Recent Posts Widget -->
    <div class="widget recent-posts-widget">
        <h3 class="widget-title">Recent Posts</h3>
        <div class="recent-posts-list">
            <?php
            $recent_posts = new WP_Query(array(
                'post_type' => 'post',
                'posts_per_page' => 5,
                'post_status' => 'publish'
            ));
            
            if ($recent_posts->have_posts()) :
                while ($recent_posts->have_posts()) : $recent_posts->the_post();
            ?>
                <div class="recent-post-item">
                    <a href="<?php the_permalink(); ?>" class="recent-post-link">
                        <div class="recent-post-thumbnail">
                            <?php if (has_post_thumbnail()) : ?>
                                <?php the_post_thumbnail('thumbnail'); ?>
                            <?php else : ?>
                                <div class="placeholder-thumbnail">🚗</div>
                            <?php endif; ?>
                        </div>
                        <div class="recent-post-content">
                            <h4 class="recent-post-title"><?php the_title(); ?></h4>
                            <span class="recent-post-date"><?php echo get_the_date(); ?></span>
                        </div>
                    </a>
                </div>
            <?php
                endwhile;
                wp_reset_postdata();
            endif;
            ?>
        </div>
    </div>
    
    <!-- Categories Widget -->
    <div class="widget categories-widget">
        <h3 class="widget-title">Categories</h3>
        <ul class="categories-list">
            <?php
            wp_list_categories(array(
                'orderby' => 'count',
                'order' => 'DESC',
                'show_count' => true,
                'title_li' => '',
                'number' => 10,
            ));
            ?>
        </ul>
    </div>
    
</aside><!-- #secondary -->
